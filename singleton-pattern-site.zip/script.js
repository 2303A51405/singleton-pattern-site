class Singleton {
    constructor() {
        if (Singleton.instance) {
            return Singleton.instance;
        }

        this.timestamp = new Date().toLocaleTimeString();

        Singleton.instance = this;
        return this;
    }
}

function createInstance() {
    const obj = new Singleton();

    document.getElementById("output").innerHTML +=
        `<p>Singleton Instance Created at: <b>${obj.timestamp}</b></p>`;
}
